// $Id: README.txt,v 1.8 2009/10/20 03:54:42 jgirlygirl Exp $

Please refer to the following for documentation:

Introduction: http://drupal.org/node/578552
Documentation: http://drupal.org/node/578574