Contributed modules written for Ubercart may be downloaded from:

http://www.ubercart.org/contrib

This is a directory of contributions by site users and developers just like you
who have decided to give back to the community.  If you're looking for a feature
that isn't included in Ubercart, you should check here first to see if someone
else has done the work!

Use this directory as a place to store the contributed modules you download.
